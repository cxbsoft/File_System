usrpas={
    "username":"cxbsoft",
    "password":"wabadmin1"
}
def sthwrt(filename,sthww):
    f=open(filename,'wb')
    f.write(sthww)
    f.close()
def sthrd(filename):
    try:
        f=open(filename,'rb')
    except:
        f=open(filename,'wb')
        f.close()
        f=open(filename,'rb')
    sthrdd=f.read()
    f.close()
    return sthrdd
def usr(username,password):
    try:
        if(usrpas['username']==username and usrpas['password']== password):
            return 200
    except:
        return 250
