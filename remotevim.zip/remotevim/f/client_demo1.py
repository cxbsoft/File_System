#coding=gbk
import socket
import os
usrpas={
    "username":"cxbsoft",
    "password":"wabadmin1"
}
portip={
    "ip":"ip",
    "port":1788
}
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect((portip['ip'],portip['port']))
filename=input("Please enter the filename you want to edit:")
#if(filename != ''):
#print("ok1")
s.send(bytes(filename.encode()))
#print("ok2")
files=s.recv(10240000)
#print("ok3")
f=open("editit.txt",'wb')
f.write(files)
f.close()
#print(1)
input("Please input 1 and enter when you finish editing:")
f=open("editit.txt",'rb')
fread=f.read()
s.send(fread)
result=s.recv(1024)
result=str(result)[2:-1]
os.remove("./editit.txt")
print(result)
