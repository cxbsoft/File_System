#coding=gbk
import socket
import time
usrpas={
    "username":"cxbsoft",
    "password":"wabadmin1"
}
portip={
    "ip":"127.0.0.1",
    "port":1788
}
s=socket.socket()
s.bind((portip["ip"],portip['port']))
s.listen(55)
print("[INFO]:system started!")
while(True):
    ip,addr=s.accept()
    filename=ip.recv(4019)
    # filename=input("Please enter the filename you want to open to edit:")
    try:
        f=open(str(filename)[2:-1],'rb')
    except:
        f1=open(str(filename)[2:-1],'wb')
        f1.close()
        time.sleep(2)
        f=open(str(filename)[2:-1],'rb')
        print("[INFO]:received the filename")
    nr=f.read()
    if(nr != b''):
        ip.send(nr)
    else:
        ip.send(bytes("No content".encode()))
    somethingrecved=ip.recv(5000)
    print("[INFO]:received the file")
    f.close()
    #print(3)
    f=open(filename,'wb')
    f.write(somethingrecved)
    #print(4)
    f.close()
    ip.send(b"Writing Successfully!")
    