import mod
import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ipport={
    "ip":"127.0.0.1",
    "port":2457
}
s.bind((ipport['ip'],ipport['port']))
s.listen(100)
while(True):
    ip,addr=s.accept()
    print(addr)
    ml=str(ip.recv(500))[2:-1]
    if(ml=="1"):
        nr=ip.recv(10240000)
        filename=ip.recv(1024)
        mod.sthwrt(filename,nr)
        ip.send(b"Uploading Sccessfully!")
    elif(ml=="2"):
        nr=mod.sthrd(str(ip.recv(1024))[2:-1])
        ip.send(bytes(nr.encode()))
        ip.send(b"Downloading Successfullly!")
