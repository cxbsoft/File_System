import socket
import mod
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ipport={
    "ip":"127.0.0.1",
    "port":2457
}
s.connect((ipport['ip'],ipport['port']))
print("Welcome to XUSOFT'S FileSystem!")
ml=input("Please enter 1 or 2(Upload,Download):")
if(ml=="1"):
    s.send(b"1")
    filename=input("Please enter the filename you want to Upload:")
    try:
        f=open(filename,'rd')
        s.send(f.read())
    except:
        print("File not found!")
        s.send("Failed")
    result=str(s.recv(1024))[2:-1]
    print(result)
elif(ml=="2"):
    s.send(b"2")
    filename=input("Please enter the filename you want to Download:")
    s.send(bytes(filename.encode()))
    nr=s.recv(10240000)
    mod.sthwrt(filename,nr)
    result=s.recv(1024)
    print(str(result)[2:-1])